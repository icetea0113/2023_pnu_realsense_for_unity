---
title: nodes-desc-end
---

It triggers the next node connected to it after the action occurs in the application. It doesn't send or receive any other data. 