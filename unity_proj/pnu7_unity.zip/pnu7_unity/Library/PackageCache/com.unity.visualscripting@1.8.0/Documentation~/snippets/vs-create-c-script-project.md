---
title: create-c-script
---

Go to **Create** &gt; **C# Script**.
