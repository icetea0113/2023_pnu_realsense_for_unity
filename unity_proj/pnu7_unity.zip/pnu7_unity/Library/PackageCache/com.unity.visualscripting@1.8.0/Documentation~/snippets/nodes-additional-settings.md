---
title: nodes-additional-settings
---

node has additional settings. Access these settings from the [Graph Inspector](../vs-interface-overview.md#the-graph-inspector):
