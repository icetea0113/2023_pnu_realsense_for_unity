---
title: tasks-note-end
---

The examples below are based on the previous example to create a Custom Scripting Event node. For more information, see [Create a Custom Scripting Event node](../../vs-create-own-custom-event-node.md)