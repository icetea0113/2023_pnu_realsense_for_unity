---
title: open-project-window
---

Go to **Window** &gt; **General** &gt; **Project**, or press Ctrl+5 (macOS: Cmd+5) to open the [Project window](https://docs.unity3d.com/Manual/ProjectView.html).
