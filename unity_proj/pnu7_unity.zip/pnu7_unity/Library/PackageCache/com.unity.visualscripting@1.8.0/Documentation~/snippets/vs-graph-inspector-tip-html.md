---
title: graph-inspector-tip-html
---


<div class="TIP"><h5>TIP</h5><p>If the Graph Inspector isn't visible in the Graph window, select <strong>Graph Inspector</strong> (<img src="../images/vs-graph-inspector-icon.png" alt="The Graph Inspector icon. A circle with a lower-case letter 'i' inside.">) from the toolbar.</p></div>
